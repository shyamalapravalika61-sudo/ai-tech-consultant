@echo off
setlocal
cd /d "%~dp0"
echo =============================================
echo AI Tech Consultant - Windows setup
 echo =============================================
where py >nul 2>nul
if errorlevel 1 (
  echo Python launcher not found. Install Python 3.11+ from python.org and try again.
  pause
  exit /b 1
)
if not exist .venv\Scripts\python.exe (
  echo Creating virtual environment...
  py -m venv .venv
  if errorlevel 1 goto failed
)
echo Installing required packages...
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto failed
echo.
echo Starting Knowledge Brain API at http://127.0.0.1:8000/docs
start "Knowledge Brain API" cmd /k "cd /d "%~dp0" && .venv\Scripts\python.exe -m uvicorn task1_knowledge_brain.app:app --host 127.0.0.1 --port 8000"
echo Wait a few seconds, then open http://127.0.0.1:8000/docs in your browser.
echo To run tests, open a second Command Prompt in this folder and run:
echo .venv\Scripts\python.exe -m pytest -q
pause
exit /b 0
:failed
echo Setup failed. Copy the error message and ask for help.
pause
exit /b 1
