"""Optional Claude client. Falls back safely to deterministic behavior without a key."""
import os, json, time, urllib.request, urllib.error

API_URL = 'https://api.anthropic.com/v1/messages'

def load_local_env():
    """Load simple KEY=VALUE settings from the project .env without overwriting OS env."""
    env_file = __import__('pathlib').Path(__file__).resolve().parent / '.env'
    if not env_file.exists():
        return
    for raw in env_file.read_text(encoding='utf-8').splitlines():
        line = raw.strip()
        if not line or line.startswith('#') or '=' not in line:
            continue
        name, value = line.split('=', 1)
        name, value = name.strip(), value.strip().strip('\"').strip("'")
        if name and name not in os.environ:
            os.environ[name] = value

load_local_env()

def claude(system: str, prompt: str, max_tokens: int = 900):
    key = os.getenv('ANTHROPIC_API_KEY', '').strip()
    if not key:
        return None, {'provider':'fallback','model':'deterministic','latency_ms':0,'estimated_cost_usd':0.0}
    model = os.getenv('ANTHROPIC_MODEL', 'claude-3-5-haiku-latest')
    body = json.dumps({'model':model,'max_tokens':max_tokens,'system':system,'messages':[{'role':'user','content':prompt}]}).encode()
    req = urllib.request.Request(API_URL, data=body, headers={'x-api-key':key,'anthropic-version':'2023-06-01','content-type':'application/json'}, method='POST')
    start=time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=35) as resp: data=json.loads(resp.read().decode())
        latency=round((time.perf_counter()-start)*1000,1)
        answer=''.join(x.get('text','') for x in data.get('content',[]) if x.get('type')=='text')
        usage=data.get('usage',{})
        # Approximate Haiku pricing is intentionally not hard-coded as a promise; report token counts instead.
        return answer, {'provider':'anthropic','model':model,'latency_ms':latency,'input_tokens':usage.get('input_tokens',0),'output_tokens':usage.get('output_tokens',0),'estimated_cost_usd':None}
    except Exception as exc:
        return None, {'provider':'fallback','model':model,'latency_ms':round((time.perf_counter()-start)*1000,1),'error':str(exc)[:300],'estimated_cost_usd':0.0}
