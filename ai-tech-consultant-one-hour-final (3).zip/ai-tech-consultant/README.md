# AI Tech Consultant — Capstone Prototype

Three connected Python workflows: a support Knowledge Brain, an Inbox Agent, and a Meeting-to-Scope assistant. This is a working prototype, not a claim that every hiring-assignment requirement is complete. Read `SUBMISSION_STATUS.md` before submission.

## Requirements and run
Python 3.11+. On Windows, double-click `run_windows.bat`, or run from PowerShell in this folder:

```powershell
py -m venv .venv
.\.venv\Scripts\python -m pip install -r requirements.txt
.\.venv\Scripts\python -m uvicorn task1_knowledge_brain.app:app --reload
```

Knowledge Brain docs: `http://127.0.0.1:8000/docs`. With the server running, open a second terminal:

```powershell
.\.venv\Scripts\python -m task2_inbox_agent.app "Profile settings" "How do I update my profile?"
.\.venv\Scripts\python -m task3_meeting_scope.app data/transcripts/01_initial_discovery.txt
.\.venv\Scripts\python -m pytest -q
.\.venv\Scripts\python scripts/run_evaluations.py
```

Optional Claude support: add your own authorized key to `.env` as `ANTHROPIC_API_KEY=...`. The key is loaded automatically by `common_llm.py`; never commit or share it. Without a key, deterministic fallback behavior is used.

## Tasks
- **Knowledge Brain:** `/ask`, `/articles`, `/feedback`, `/health`; source metadata, unsupported-question review queue, polite resumable crawler, image alt/src metadata.
- **Inbox Agent:** run with `uvicorn task2_inbox_agent.app:app --port 8001`; `/draft`, `/audit`, `/review`, and `/rollback/{category}`. Drafts require human review; sending is always disabled.
- **Meeting to Scope:** run with `uvicorn task3_meeting_scope.app:app --port 8002`; `POST /scope` returns candidate scope, assumptions, questions, estimates, capability checks, and a proposal draft.

## Data and evaluation
`data/customer_emails.json` contains 50 synthetic emails. `data/transcripts/` contains meeting role-plays and a follow-up. `scripts/run_evaluations.py` runs 60 deterministic functional checks (20 per task) and records results. These are not human-rated LLM evaluations or model comparisons; see `EVALS.md`.

## Important limitations
Bundled articles are fictional demos until a real crawl is completed and reviewed. Retrieval uses keyword overlap, image metadata is stored but images are not visually interpreted, and local JSON storage is for demonstration only. API-key-based model comparisons, full end-to-end quality evaluation, public GitHub/deployment links, demo video, and authentic multi-day commit history still require real execution and evidence. Do not claim these are complete.
