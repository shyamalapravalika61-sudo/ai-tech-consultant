from fastapi.testclient import TestClient
from task1_knowledge_brain.app import app as brain_app
from task2_inbox_agent.app import app as inbox_app, classify
from task3_meeting_scope.app import app as scope_app, parse_json

brain = TestClient(brain_app)
inbox = TestClient(inbox_app)
scope = TestClient(scope_app)

def test_brain_health():
    r = brain.get('/health')
    assert r.status_code == 200 and r.json()['status'] == 'ok'

def test_known_question_has_source():
    r = brain.post('/ask', json={'question': 'How do I update my profile settings?'})
    assert r.status_code == 200 and r.json()['sources'] and 'profile' in r.json()['answer'].lower()

def test_short_question_rejected():
    assert brain.post('/ask', json={'question': 'x'}).status_code == 422

def test_inbox_classification():
    assert classify('Please refund my payment') == 'refund'
    assert classify('How do I reset my password?') == 'how_to'

def test_inbox_health_never_sends():
    r = inbox.get('/health')
    assert r.status_code == 200 and r.json()['sending_enabled'] is False

def test_scope_health_requires_review():
    r = scope.get('/health')
    assert r.status_code == 200 and r.json()['human_approval_required'] is True

def test_json_parser():
    assert parse_json('{"scope_items":["login"]}')['scope_items'] == ['login']
    assert parse_json('not json') is None

def test_review_endpoint_rejects_unknown_draft():
    r = inbox.post('/review', json={'draft_id': 'does-not-exist', 'approved': True})
    assert r.status_code == 404

def test_rollback_pauses_category(monkeypatch, tmp_path):
    import task2_inbox_agent.app as module
    monkeypatch.setattr(module, 'PAUSES', tmp_path / 'pauses.json')
    r = inbox.post('/rollback/quote')
    assert r.status_code == 200
    assert r.json()['automation_paused'] is True
    assert 'quote' in module._paused_categories()
