# Final submission checklist

This repository is a prototype with offline checks, not a claim that every hiring-assignment requirement is complete.

## Verified in the current prepared package
- `python -m pytest -q`: 9 tests passed.
- `python scripts/run_evaluations.py`: 60 deterministic offline functional checks passed (20 per task).
- The local tests do not establish model quality, live crawl coverage, production readiness, or completion of hidden tests.

## Before submission
- [ ] Add an authorized Anthropic API key locally if required; never commit `.env` or share the key.
- [ ] Run the crawler against the official sitemap with a small limit first; review saved content and failures. Do not claim a full crawl until verified.
- [ ] Verify all three APIs from their Swagger pages and capture actual demo footage.
- [ ] Run the required human-rated 20–30 cases per model/configuration and record actual quality, latency, and cost. Do not relabel deterministic checks as model evaluation.
- [ ] Create the GitHub repository in your own account, push the code, and verify the link is public/accessibly shared.
- [ ] Record and upload your own demo video; paste only working links in the submission form.
- [ ] Submit honestly: do not claim full completion while required evaluation/deployment/demo evidence remains missing.

## Quick start (Windows PowerShell)
```powershell
py -m venv .venv
.\.venv\Scripts\python -m pip install -r requirements.txt
.\.venv\Scripts\python -m pytest -q
.\.venv\Scripts\python scripts/run_evaluations.py
.\.venv\Scripts\python -m uvicorn task1_knowledge_brain.app:app --reload
```
Open `http://127.0.0.1:8000/docs`.
