# Design Document — AI Tech Consultant

## 1. Goals and system boundary
The prototype combines three Python components for a service business: (1) retrieve supported answers from support articles, (2) prepare customer email replies, and (3) convert meeting notes into a preliminary scope and estimate. The Knowledge Brain is the shared source-of-truth interface. All consequential outputs remain drafts and require human review. There is no outbound email sender or automatic account modification.

```text
Public support sitemap -> polite crawler -> JSON article store -> Knowledge Brain API
                                                              ^             ^
                                                              | HTTP        | HTTP
                                                        Inbox Agent   Meeting-to-Scope
                                                        draft/review   scope/change review
```

FastAPI provides HTTP endpoints, Pydantic validates input shapes, JSON files persist the prototype state, and `common_llm.py` makes an optional Anthropic Messages API call. If no key is present or the call fails, each workflow falls back to a deterministic path and reports the provider/failure metadata. The local JSON persistence is appropriate only for a single-user demonstration; concurrent writes and multi-instance deployment need a database and locking.

## 2. Task 1 — Knowledge Brain

### Request flow
`POST /ask` validates a question, loads bundled demo articles plus crawled and human-feedback articles, scores title/content token overlap, and selects the best few matches. If nothing matches, it writes the question to `data/review_queue.json` and returns an explicit unsupported response with `needs_human_review=true`. If sources match, the prompt tells Claude to use only supplied source text and to abstain when unsupported. Responses return source titles, source URLs, and image metadata. `POST /feedback` stores an expert answer separately; `GET /articles` exposes indexed article metadata; `/health` exposes status.

### Ingestion and media
`scripts/crawl_sitemap.py` restricts the sitemap and article URLs to the Brilliant Directories support host, uses a descriptive user agent, retries transient HTTP failures, supports nested sitemap indexes, enforces a delay, checkpoints progress, and stores partial results after each page. It extracts title, text, image source, alt text, and title metadata. A new UTC date starts a fresh crawl pass; same-day reruns can resume. Optional removal reconciliation should be used only when the configured limit covers the full sitemap. Image metadata is associated with its article, but the code does not download images or perform visual/vision interpretation. A human must inspect crawl coverage and output.

### Known retrieval limits
The baseline is token-overlap search, not semantic embeddings. The bundled articles are fictional demo data, not verified official documentation. The system must not be described as having complete support coverage until a full crawl has been run and reviewed. A production version should add stable article IDs, content hashing, chunking, semantic retrieval, robust deleted-page reconciliation, scheduled execution, and a reviewed multimodal pipeline.

## 3. Task 2 — Inbox Agent

The classifier uses transparent keyword rules for refund, complaint, quote, project request, follow-up, how-to, and other. The agent asks Knowledge Brain for evidence, then drafts a concise reply with Claude when configured. If the knowledge service fails or cannot support an answer, the fallback asks a teammate to verify instead of promising a refund, price, deadline, legal result, or account change.

The API exposes `/health`, `POST /draft`, `GET /audit`, `POST /review`, and `POST /rollback/{category}`. Drafts are written to a JSON audit file. A reviewer can approve, reject, or provide an edited reply. The threshold counts unchanged approved drafts by category; reaching the configured threshold marks the category eligible for a separate automation review. A category pause is persisted as a rollback control. **Sending remains disabled at all times in this prototype**: the threshold is not permission to send messages, and a real delivery integration would require separate authorization, safety review, monitoring, and rollback.

The included 50 emails are synthetic. Classification accuracy on the small local test set is not a guarantee of accuracy on real customer mail. A production deployment needs privacy controls, access control, durable storage, stronger classifier evaluation, idempotency, audit retention rules, and reviewer authentication.

## 4. Task 3 — Meeting to Scope

The API accepts a client name, transcript, and optional previous scope. Claude is prompted to return JSON containing scope items, assumptions, open questions, risks, acceptance criteria, and task-hour ranges. When model output is absent or invalid, a clearly caveated line-based fallback creates candidate items and broad estimates. Each candidate item is sent to Knowledge Brain for a capability check. The output includes a draft proposal, totals, added/removed scope comparison, and `human_approval_required=true`.

The supplied transcript set includes discovery conversations, a custom-search discussion, and a follow-up. Scope comparison currently compares item text; it is not a semantic requirement tracker. Estimates are planning ranges, not commitments. A stronger version should use stable requirement IDs, source spans, an approved baseline, explicit acceptance criteria, and human-reviewed change diffs.

## 5. Reliability, safety, and privacy
- Unanswered knowledge questions are escalated; source metadata is returned when available.
- Email drafts are never sent by this application; approval and rollback events are auditable locally.
- Proposals and estimates remain unapproved drafts.
- HTTP clients use timeouts; crawler requests use retries and a delay.
- Treat article content and customer text as untrusted input. Prompts explicitly constrain model behavior.
- Never commit `.env`, API keys, private customer information, or secrets. The repository contains synthetic examples only.
- Local JSON writes are not a substitute for transactional database storage.

## 6. Evaluation design
`python scripts/run_evaluations.py` runs 60 deterministic functional cases, 20 per task. It records outcomes and local timing in `data/evaluations/local_functional_results.json`. The latest recorded run passed all 60 cases. These are intentionally narrow checks of retrieval/no-match behavior, rule classification, and JSON parser behavior; they are not human-rated answer-quality evaluations and do not compare Claude models. `python -m pytest -q` runs API smoke tests. Model quality, live crawl coverage, external API cost, and full end-to-end acceptance remain separate evaluation tasks; see `EVALS.md` and `SUBMISSION_STATUS.md`.
