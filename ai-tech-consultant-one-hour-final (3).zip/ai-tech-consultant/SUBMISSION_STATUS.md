# Submission status — read before submitting

## Implemented and locally checked
- FastAPI Knowledge Brain with local article retrieval, source metadata, unsupported-question review queue, expert feedback storage, and health/article endpoints.
- Optional Anthropic Messages API client with deterministic fallback behavior when no key is configured.
- Resumable support sitemap crawler with retry configuration, page delay, article text extraction, image alt/src metadata, and crawl checkpointing.
- Inbox Agent API with classification, Knowledge Brain lookup, reply drafting, audit trail, human approve/reject/edit, unchanged-approved-draft threshold, and category pause/rollback control. The prototype never sends email.
- Meeting-to-Scope API with structured Claude prompt, deterministic fallback, capability checks, estimate ranges, proposal draft, and follow-up item comparison.
- 50 synthetic customer emails and four transcript examples, including a follow-up.
- 60 local functional cases (20 per task) and 9 pytest checks. Latest local run: 60/60 functional cases passed and 9/9 tests passed. Results are in `data/evaluations/local_functional_results.json`.

## Not complete / cannot honestly be claimed complete
- Required Claude model comparison and human-rated 20–30-case-per-model evaluation: no valid API key was available; no model-quality result is claimed.
- Full visual image understanding; current crawler only associates image URLs/alt metadata with articles.
- Verified full sitemap crawl, scheduled daily execution in a host environment, and validated removal reconciliation.
- Production-grade semantic retrieval, database-backed persistence, concurrency controls, authentication, and security review.
- Live deployment URL, public GitHub URL, demo video, and authentic four-day commit history. These require account access and real actions; no fake links or evidence are included.
- Authentic AI coding-assistant chat export and rejected-answer evidence for `AI_LOG.md` must be supplied from the actual tool history rather than fabricated.

## Submission guidance
Submit only links that you personally verified open and contain the intended project. Do not paste an API key into the form or commit it to GitHub. If the form asks whether the entire assignment is complete, the honest answer is **not yet**, until the pending items above are addressed.
