# AI Tool Use Log — truthful record

This log records the relevant prompts and response correction visible in the current ChatGPT conversation. It is not a substitute for exporting the full AI coding-tool history if the hiring team requires that artifact.

1. **Actual user prompt:** “how to complete this assement” — purpose: requested a practical completion plan. **Correction:** the earlier response only guided the user through downloading/extracting the prototype; it did not finish the capstone.
2. **Actual user prompt:** “you did not completed the assement aa” — purpose: pointed out that a starter package was not a completed submission. **Accepted changes:** implementation work continued rather than claiming completion.
3. **Actual user prompt:** “i will take care of my self pls complete the assement pls” — purpose: asked for the project to be completed. **Accepted changes:** expanded Task 2 into a review/audit API, added rollback pause control, improved the crawler, updated Task 3 API structure, and added local functional evaluations and tests.
4. **Actual user prompt:** “i am not felling will i should go to hospali pls do it for me” — purpose: requested assistance while feeling unwell. **Safety note:** health guidance was given before continuing technical work.
5. **Actual user prompt:** “i will take care of my self pls complete the assement pls” — purpose: repeated the request to continue technical completion. **Accepted changes:** documentation and evaluation reporting were revised to separate verified local results from pending model-quality/deployment requirements.

## Rejected answer and correction
**Actual earlier assistant answer (short excerpt):** “I prepared the starter project, but I have not completed the entire assessment yet.” The user correctly indicated that this did not meet the request to complete the work. The implementation was then expanded and tested locally. The current project still does not include the required real Claude model comparison, public deployment, GitHub publication, demo video, or authentic multi-day commit history; these are disclosed in `SUBMISSION_STATUS.md` rather than being falsely marked complete.

**Evidence limitation:** This conversation log is not a full export of every coding interaction, and it does not prove use of a separate coding assistant. If the evaluator requires the complete native AI-tool thread, export it from the tool actually used and attach it. No fabricated conversation or model output is included.
