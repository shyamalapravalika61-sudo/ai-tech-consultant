# Evaluation Plan and Results

## Local functional results
The latest offline run executed 60 deterministic checks: 20 per task. All passed on this run. This is a narrow functional baseline, not a human-rated answer-quality evaluation and not a model comparison.

| Task | Passed / run | Accuracy | Median latency (ms) | p95 latency (ms) | External API cost/case |
|---|---:|---:|---:|---:|---:|
| Knowledge Brain retrieval | 20 / 20 | 100% | 0.053 | 0.230 | $0.00 |
| Inbox classification | 20 / 20 | 100% | 0.002 | 0.008 | $0.00 |
| Scope JSON parser behavior | 20 / 20 | 100% | 0.002 | 0.049 | $0.00 |

Machine timings vary. Task 1 checks relevant retrieval on known demo questions and no retrieval on selected unrelated questions. Task 2 checks a small rule-classification set. Task 3 checks JSON parsing versus fallback behavior, not the correctness of generated scopes or hour estimates. Full case-level observed outcomes and timings are saved in `data/evaluations/local_functional_results.json`. Re-run with `python scripts/run_evaluations.py` to refresh them.

`python -m pytest -q` passed 9 automated API/basic behavior tests in the current local run. The smoke tests and functional cases use local demo data and do not call Claude or the live support sitemap.

## Required model-quality evaluation still pending
The hiring brief asks for repeated evaluations per model/configuration and comparison of quality, speed, and cost. No valid Anthropic API key was available during this work, so no Claude model-to-model comparison or human scoring is claimed. The table above must not be presented as Claude quality scores.

To finish this requirement, freeze the prompts and cases; run the same 20–30 cases per task against each selected Claude model; have a human score groundedness, citation accuracy, abstention, email safety, requirement coverage, and change detection; record exact model IDs, prompt versions, token usage, latency, errors, and the provider's current pricing source; and calculate median/p95 latency and actual cost per case. Do not fabricate values.

## Known evaluation gaps
- Live crawl coverage and the quality of official article content have not been measured.
- No vision evaluation exists; image URLs and alt text are stored but images are not visually interpreted.
- Inbox classification results are for a small, hand-authored test set and do not imply real-world generalization.
- Meeting-to-scope extraction, hour-estimate calibration, and proposal quality require human-rated transcripts.
- Hidden acceptance tests, deployment reliability, concurrency, and security have not been validated.
