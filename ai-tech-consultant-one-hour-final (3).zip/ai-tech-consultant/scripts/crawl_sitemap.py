"""Polite, resumable sitemap crawler with retries, sitemap-index support and deletion reconciliation.

Run manually with CRAWL_LIMIT and CRAWL_DELAY. It never bypasses access controls.
The crawler preserves image alt/src metadata; it does not claim visual image understanding.
"""
import json, os, time
from pathlib import Path
from urllib.parse import urlparse
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data'
SITEMAP = 'https://support.brilliantdirectories.com/support/sitemap.xml'
OUT = DATA / 'crawled_articles.json'
CHECK = DATA / 'crawl_checkpoint.json'
HEADERS = {'User-Agent': 'StudentCapstoneResearchBot/1.1 (polite educational crawler)'}
ALLOWED_HOST = 'support.brilliantdirectories.com'


def session_with_retries():
    session = requests.Session()
    session.headers.update(HEADERS)
    retry = Retry(total=4, connect=4, read=3, backoff_factor=1.0,
                  status_forcelist=(429, 500, 502, 503, 504),
                  allowed_methods=frozenset(['GET']), respect_retry_after_header=True)
    session.mount('https://', HTTPAdapter(max_retries=retry))
    session.mount('http://', HTTPAdapter(max_retries=retry))
    return session


def get_locs(session, sitemap_url, seen=None):
    seen = seen or set()
    if sitemap_url in seen:
        return []
    seen.add(sitemap_url)
    if urlparse(sitemap_url).netloc != ALLOWED_HOST:
        return []
    response = session.get(sitemap_url, timeout=30)
    response.raise_for_status()
    soup = BeautifulSoup(response.content, 'xml')
    locs = [x.get_text(strip=True) for x in soup.find_all('loc')]
    # Support nested sitemap indexes as well as normal urlsets.
    if soup.find('sitemapindex'):
        found = []
        for loc in locs:
            found.extend(get_locs(session, loc, seen))
        return found
    return [u for u in locs if urlparse(u).netloc == ALLOWED_HOST and urlparse(u).scheme == 'https']


def main(limit=100, delay=1.2, reconcile=False):
    DATA.mkdir(exist_ok=True)
    session = session_with_retries()
    urls = sorted(set(get_locs(session, SITEMAP)))
    today = time.strftime('%Y-%m-%d', time.gmtime())
    state = json.loads(CHECK.read_text(encoding='utf-8')) if CHECK.exists() else {'done': [], 'errors': []}
    # A new UTC day starts a fresh incremental refresh; same-day reruns resume checkpoints.
    if state.get('run_date') != today:
        state = {'done': [], 'errors': state.get('errors', []), 'run_date': today}
    existing_list = json.loads(OUT.read_text(encoding='utf-8')) if OUT.exists() else []
    existing = {a['source_url']: a for a in existing_list if a.get('source_url')}
    done = set(state.get('done', []))
    processed = 0
    for url in urls:
        if url in done or processed >= limit:
            continue
        try:
            r = session.get(url, timeout=30)
            r.raise_for_status()
            page = BeautifulSoup(r.text, 'html.parser')
            for tag in page(['script', 'style', 'nav', 'footer', 'header', 'noscript']):
                tag.decompose()
            title = page.title.get_text(' ', strip=True) if page.title else url
            main_node = page.find('main') or page.find('article') or page.body
            content = ' '.join(main_node.stripped_strings) if main_node else ''
            images = []
            if main_node:
                for img in main_node.find_all('img'):
                    src = img.get('src') or img.get('data-src') or ''
                    if src:
                        from urllib.parse import urljoin
                        src = urljoin(url, src)
                    images.append({'alt': img.get('alt', ''), 'src': src, 'title': img.get('title', '')})
            if content:
                existing[url] = {'title': title, 'content': content[:30000], 'source_url': url,
                                 'images': images, 'crawled_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
            done.add(url)
            state['errors'] = [e for e in state.get('errors', []) if e.get('url') != url]
        except Exception as exc:
            state.setdefault('errors', []).append({'url': url, 'error': str(exc)[:300], 'attempted_at': time.time()})
        processed += 1
        state.update({'done': sorted(done), 'last_sitemap_urls': urls, 'last_run_at': time.time()})
        CHECK.write_text(json.dumps(state, indent=2), encoding='utf-8')
        OUT.write_text(json.dumps(list(existing.values()), indent=2, ensure_ascii=False), encoding='utf-8')
        time.sleep(max(0.2, delay))
    removed = []
    if reconcile and limit >= len(urls):
        current = set(urls)
        removed = sorted(set(existing) - current)
        for url in removed:
            existing.pop(url, None)
        OUT.write_text(json.dumps(list(existing.values()), indent=2, ensure_ascii=False), encoding='utf-8')
    print(f'Processed {processed}; sitemap URLs {len(urls)}; saved {len(existing)} articles; errors {len(state.get("errors", []))}; removed {len(removed)}')

if __name__ == '__main__':
    main(int(os.getenv('CRAWL_LIMIT', '100')), float(os.getenv('CRAWL_DELAY', '1.2')),
         os.getenv('CRAWL_RECONCILE_REMOVALS', 'false').lower() == 'true')
