"""Run reproducible local functional evaluations (not a substitute for model-quality review).
No external API is called. Outputs include observed results and elapsed time for all 60 cases.
"""
import json, sys, time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from task1_knowledge_brain.app import retrieve
from task2_inbox_agent.app import classify
from task3_meeting_scope.app import parse_json

TASK1 = [
('How do I update my profile settings?', True), ('Where can I edit my account profile?', True),
('How do I save profile changes?', True), ('Who do I contact for billing questions?', True),
('Should I send my password to support?', True), ('How can I request a website change?', True),
('What details should I include in a website change request?', True), ('Can support promise a refund?', True),
('Does refund eligibility depend on account details?', True), ('How do I reset a profile field?', True),
('What is the process for custom website work?', True), ('Where do I find profile settings?', True),
('How can I ask about billing?', True), ('What should I include when contacting support?', True),
('Is a refund guaranteed for every account?', True), ('How do I update my settings and save?', True),
('How do I control quantum teleportation?', False), ('What is the moon made of?', False),
('Can you configure a nuclear reactor?', False), ('Tell me tomorrow lottery numbers', False),
]
TASK2 = [
('How do I reset my password?', 'how_to'), ('Please cancel and refund my payment', 'refund'),
('I am unhappy with the broken site', 'complaint'), ('Can you send me a price quote?', 'quote'),
('I need a new website built', 'project_request'), ('Checking in for a status update', 'follow_up'),
('The service is broken and I am angry', 'complaint'), ('What does the custom project cost?', 'quote'),
('Where do I change the setting?', 'how_to'), ('Please give my money back', 'refund'),
('Any update on my request?', 'follow_up'), ('We need a custom feature', 'project_request'),
('I want to file a complaint', 'complaint'), ('How much is the estimate?', 'quote'),
('I cannot login to my account', 'how_to'), ('Cancel my plan please', 'refund'),
('I am checking in on my request', 'follow_up'), ('Build a new feature for us', 'project_request'),
('The support was disappointing', 'complaint'), ('Please share pricing', 'quote'),
]
TASK3 = [
('We need a login page', 'fallback'), ('not json', 'fallback'), ('{"scope_items":["login"]}', 'json'),
('The client needs a member dashboard', 'fallback'), ('{"scope_items":[]}', 'json'),
('no structured result', 'fallback'), ('{"scope_items":["search"],"risks":[]}', 'json'),
('scope should be discussed later', 'fallback'), ('{"a":1}', 'json'), ('broken { json', 'fallback'),
('[]', 'json'), ('', 'fallback'), ('{"scope_items":["checkout"]}', 'json'),
('N/A', 'fallback'), ('{"task_estimates":[]}', 'json'), ('- Login page', 'fallback'),
('{"scope_items":["profile","billing"]}', 'json'), ('not a json object', 'fallback'),
('{"open_questions":["deadline?"]}', 'json'), ('missing result', 'fallback'),
]

def run():
    results=[]
    for i,(q,expected) in enumerate(TASK1,1):
        t=time.perf_counter(); observed=bool(retrieve(q)); ms=round((time.perf_counter()-t)*1000,3)
        results.append({'task':'task1','case_id':f'T1-{i:02}','input':q,'expected':expected,'observed':observed,'pass':observed==expected,'latency_ms':ms,'cost_usd':0.0})
    for i,(q,expected) in enumerate(TASK2,1):
        t=time.perf_counter(); observed=classify(q); ms=round((time.perf_counter()-t)*1000,3)
        results.append({'task':'task2','case_id':f'T2-{i:02}','input':q,'expected':expected,'observed':observed,'pass':observed==expected,'latency_ms':ms,'cost_usd':0.0})
    for i,(q,expected) in enumerate(TASK3,1):
        t=time.perf_counter(); observed='json' if parse_json(q) is not None else 'fallback'; ms=round((time.perf_counter()-t)*1000,3)
        # JSON arrays are valid JSON, even though production scope requires an object; score parser behavior only.
        results.append({'task':'task3','case_id':f'T3-{i:02}','input':q,'expected':expected,'observed':observed,'pass':observed==expected,'latency_ms':ms,'cost_usd':0.0})
    summary={}
    for task in ('task1','task2','task3'):
        group=[r for r in results if r['task']==task]
        lat=sorted(r['latency_ms'] for r in group)
        summary[task]={'passed':sum(r['pass'] for r in group),'total':len(group),'accuracy':round(sum(r['pass'] for r in group)/len(group),3),
                       'median_latency_ms':lat[len(lat)//2], 'p95_latency_ms':lat[min(len(lat)-1, int(.95*len(lat)))], 'model':'deterministic local baseline','cost_usd_per_case':0.0}
    out={'scope':'Local deterministic functional checks only; not a human-rated LLM evaluation or model comparison.','summary':summary,'results':results}
    path=ROOT/'data'/'evaluations'/'local_functional_results.json'; path.parent.mkdir(exist_ok=True,parents=True)
    path.write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding='utf-8')
    print(json.dumps(summary,indent=2)); print(f'Saved {path}')
if __name__=='__main__': run()
